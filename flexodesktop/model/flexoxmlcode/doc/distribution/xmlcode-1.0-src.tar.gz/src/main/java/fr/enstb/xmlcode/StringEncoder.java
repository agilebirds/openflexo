/**************************************************************************
 * StringEncoder.java
 *
 * XMLCoDe project - A free java implementation of an XML coder/decoder
 *
 * Copyright (c) 2001-2007 by Sylvain Guerin (sylvain.guerin@denali.be)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by  the Free Software Foundation; either version 2.1 of the License or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 **************************************************************************/

package fr.enstb.xmlcode;

import java.awt.Point;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.StringTokenizer;

/**
 * Utility class used to encode objects
 * 
 * @author sguerin
 */
public class StringEncoder
{

    public static String encodeBoolean(boolean aBoolean)
    {
        return (aBoolean ? "true" : "false");
    }

    public static String encodeByte(byte aByte)
    {
        return "" + aByte;
    }

    public static String encodeCharacter(char aChar)
    {
        return "" + aChar;
    }

    public static String encodeDouble(double aDouble)
    {
        return "" + aDouble;
    }

    public static String encodeFloat(float aFloat)
    {
        return "" + aFloat;
    }

    public static String encodeInteger(int anInt)
    {
        return "" + anInt;
    }

    public static String encodeLong(long aLong)
    {
        return "" + aLong;
    }

    public static String encodeShort(short aShort)
    {
        return "" + aShort;
    }

    public static boolean decodeAsBoolean(String value)
    {
        return value.equalsIgnoreCase("true") || value.equalsIgnoreCase("yes");
    }

    public static byte decodeAsByte(String value)
    {
        return Byte.parseByte(value);
    }

    public static char decodeAsCharacter(String value)
    {
        return value.charAt(0);
    }

    public static double decodeAsDouble(String value)
    {
        return Double.parseDouble(value);
    }

    public static float decodeAsFloat(String value)
    {
        return Float.parseFloat(value);
    }

    public static int decodeAsInteger(String value)
    {
        if (value == null) return -1;
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return (int) decodeAsDouble(value);
        }
    }

    public static long decodeAsLong(String value)
    {
        return Long.parseLong(value);
    }

    public static short decodeAsShort(String value)
    {
        return Short.parseShort(value);
    }

    public static Object decodeObject(String value, Class objectType)
    {
        if (!isInitialized) {
            initialize();
        }
        if (value == null) {
            return null;
        }
        Converter converter = converterForClass(objectType);
        if (converter != null) {
            return converter.convertFromString(value);
        } else {
            throw new InvalidDataException("Supplied value has no converter for type " + objectType.getName());
        }
    }

    public static String encodeObject(Object object)
    {
        if (!isInitialized) {
            initialize();
        }
        if (object == null) {
            return null;
        }
        Converter converter = converterForClass(object.getClass());
        if (converter != null) {
            return converter.convertToString(object);
        } else {
            if (object instanceof StringConvertable) {
                converter = ((StringConvertable) object).getConverter();
                if (converter != null) {
                    // System.out.println ("Registering my own converter");
                    addConverter(converter);
                    return converter.convertToString(object);
                }
            }
            throw new InvalidDataException("Supplied value has no converter for type " + object.getClass().getName());
        }
    }

    public static Converter converterForClass(Class objectType)
    {
        if (!isInitialized) {
            initialize();
        }
        /*
         * System.out.println ("I've got those converters:"); for (Enumeration e =
         * converters.keys(); e.hasMoreElements();) { Class key =
         * (Class)e.nextElement(); Converter converter =
         * (Converter)converters.get(key); System.out.println ("Key: "+key+"
         * Converter: "+converter.getConverterClass().getName()); }
         */
        Converter returned;
        Class tryThis = objectType;
        boolean iAmAtTheTop = false;
        do {
            returned = (Converter) converters.get(tryThis);
            iAmAtTheTop = tryThis.equals(Object.class);
            if (!iAmAtTheTop) {
                tryThis = tryThis.getSuperclass();
            }
        } while ((returned == null) && (!iAmAtTheTop) && (tryThis != null));
        return returned;
    }

    public static boolean isConvertable(Class objectType)
    {
        if (!isInitialized) {
            initialize();
        }
        return (converterForClass(objectType) != null);
    }

    /**
     * Sets date format, under the form
     * <code>"yyyy.MM.dd G 'at' HH:mm:ss a zzz"</code>
     */
    public static void setDateFormat(String aFormat)
    {
        DateConverter dc = (DateConverter) converterForClass(Date.class);
        dc._dateFormat = aFormat;
    }

    public static String getDateFormat()
    {
        DateConverter dc = (DateConverter) converterForClass(Date.class);
        return dc._dateFormat;
    }
    
    /**
     * Return a string representation of a date, according to valid date format
     */
    public static String getDateRepresentation(Date aDate)
    {
        DateConverter dc = (DateConverter) converterForClass(Date.class);
        return dc.getDateRepresentation(aDate);
    }

    private static Hashtable converters = new Hashtable();

    private static boolean isInitialized = false;

    public static Converter addConverter(Converter converter)
    {
        converters.put(converter.getConverterClass(), converter);
        return converter;
    }

    public static void initialize()
    {
        if (!isInitialized) {
            addConverter(new BooleanConverter());
            addConverter(new IntegerConverter());
            addConverter(new NumberConverter());
            addConverter(new StringConverter());
            addConverter(new DateConverter());
            addConverter(new URLConverter());
            addConverter(new FileConverter());
            addConverter(new ClassConverter());
            addConverter(new PointConverter());
            isInitialized = true;
        }
    }

    /**
     * Abstract class defining a converter to and from a String for a given
     * class
     * 
     * @author sguerin
     */
    public static abstract class Converter
    {

        protected Class converterClass;

        public Converter(Class aClass)
        {
            super();
            converterClass = aClass;
        }

        public Class getConverterClass()
        {
            return converterClass;
        }

        public abstract Object convertFromString(String value);

        public abstract String convertToString(Object value);

    }

    /**
     * Class defining how to convert Boolean from/to String
     * 
     * @author sguerin
     */
    public static class BooleanConverter extends Converter
    {

        protected BooleanConverter()
        {
            super(Boolean.class);
        }

        public Object convertFromString(String value)
        {
            return new Boolean(value.equalsIgnoreCase("true") || value.equalsIgnoreCase("yes"));
        }

        public String convertToString(Object value)
        {
            return ((Boolean) value).toString();
        }

    }

    /**
     * Class defining how to convert Integer from/to String
     * 
     * @author sguerin
     */
    public static class IntegerConverter extends Converter
    {

        protected IntegerConverter()
        {
            super(Integer.class);
        }

        public Object convertFromString(String value)
        {
            return new Integer(value);
        }

        public String convertToString(Object value)
        {
            return ((Integer) value).toString();
        }

    }

    /**
     * Class defining how to convert Number from/to String
     * (try to deserialize - in this order - as an (1) integer, (2) float (3) double)
     * 
     * @author sguerin
     */
    public static class NumberConverter extends Converter
    {

        protected NumberConverter()
        {
            super(Number.class);
        }

        public Object convertFromString(String value)
        {
            try {
                return new Integer(value);
            }
            catch (NumberFormatException ex) {
                try {
                    return new Float(value);
                }
                catch (NumberFormatException ex2) {
                    try {
                        return new Double(value);
                    }
                    catch (NumberFormatException ex3) {
                        return null;
                    }
               }
            }
        }

        public String convertToString(Object value)
        {
            return ((Number) value).toString();
        }

    }

    /**
     * Class defining how to convert String from/to String (easy !)
     * 
     * @author sguerin
     */
    public static class StringConverter extends Converter
    {

        protected StringConverter()
        {
            super(String.class);
        }

        public Object convertFromString(String value)
        {
            return value;
        }

        public String convertToString(Object value)
        {
            return (String) value;
        }

    }

    /**
     * Class defining how to convert String from/to Date
     * 
     * @author sguerin
     */
    public static class DateConverter extends Converter
    {

        /** Specify date format */
        private String _dateFormat = new SimpleDateFormat().toPattern();

        protected DateConverter()
        {
            super(Date.class);
        }

        public Object convertFromString(String value)
        {
            try {
                StringTokenizer st = new StringTokenizer(value, ",");
                String dateFormat = _dateFormat;
                String dateAsString = null;
                if (st.hasMoreTokens()) {
                    dateFormat = st.nextToken();
                }
                if (st.hasMoreTokens()) {
                    dateAsString = st.nextToken();
                }
                if (dateAsString != null) {
                    return (Date) (new SimpleDateFormat(dateFormat)).parse(dateAsString);
                }
            } catch (ParseException e) {
            }
            SimpleDateFormat formatter = new SimpleDateFormat(_dateFormat);
            Date currentTime = new Date();
            String dateString = formatter.format(currentTime);
            System.err.println("Supplied value is not parsable as a date. " + " Date format should be for example " + dateString);
            return null;
        }

        public String convertToString(Object value)
        {
            Date date = (Date) value;
            if (date != null) {
                return _dateFormat + "," + new SimpleDateFormat(_dateFormat).format(date);
            } else {
                return null;
            }
        }

        /**
         * Return a string representation of a date, according to valid date
         * format
         */
        public String getDateRepresentation(Date date)
        {
            if (date != null) {
                return new SimpleDateFormat(_dateFormat).format(date);
            } else {
                return null;
            }
        }

    }

    /**
     * Class defining how to convert String from/to URL
     * 
     * @author sguerin
     */
    public static class URLConverter extends Converter
    {

        protected URLConverter()
        {
            super(URL.class);
        }

        public Object convertFromString(String value)
        {
            try {
                return new URL(value);
            } catch (MalformedURLException e) {
                System.err.println("Supplied value is not parsable as an URL:" + value);
                return null;
            }
        }

        public String convertToString(Object value)
        {
            URL anURL = (URL) value;
            if (anURL != null) {
                return anURL.toExternalForm();
            } else {
                return null;
            }
        }

    }

    /**
     * Class defining how to convert String from/to File
     * 
     * @author sguerin
     */
    public static class FileConverter extends Converter
    {

        protected FileConverter()
        {
            super(File.class);
        }

        public Object convertFromString(String value)
        {
            return new File(value);
        }

        public String convertToString(Object value)
        {
            File aFile = (File) value;
            if (aFile != null) {
                return aFile.getAbsolutePath();
            } else {
                return null;
            }
        }

    }

    /**
     * Class defining how to convert String from/to Class
     * 
     * @author sguerin
     */
    public static class ClassConverter extends Converter
    {

        protected ClassConverter()
        {
            super(Class.class);
        }

        public Object convertFromString(String value)
        {
            try {
                return Class.forName(value);
            } catch (ClassNotFoundException e) {
                // Warns about the exception
                throw new InvalidDataException("Supplied value represents a class not found: " + value);
            }
        }

        public String convertToString(Object value)
        {
            Class aClass = (Class) value;
            if (aClass != null) {
                return aClass.getName();
            } else {
                return null;
            }
        }

    }

    /**
     * Class defining how to convert String from/to Class
     * 
     * @author sguerin
     */
    public static class PointConverter extends Converter
    {

        protected PointConverter()
        {
            super(Point.class);
        }

        public Object convertFromString(String value)
        {
            try {
                Point returned = new Point();
                StringTokenizer st = new StringTokenizer(value, ",");
                if (st.hasMoreTokens()) {
                    returned.x = Integer.parseInt(st.nextToken());
                }
                if (st.hasMoreTokens()) {
                    returned.y = Integer.parseInt(st.nextToken());
                }
                return returned;
            } catch (NumberFormatException e) {
                // Warns about the exception
                System.err.println("Supplied value is not parsable as a Point:" + value);
                return null;
            }
        }

        public String convertToString(Object value)
        {
            Point aPoint = (Point) value;
            if (aPoint != null) {
                return aPoint.x + "," + aPoint.y;
            } else {
                return null;
            }
        }

    }

}
