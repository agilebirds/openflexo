/**************************************************************************
 * SingleKeyValueProperty.java
 *
 * XMLCoDe project - A free java implementation of an XML coder/decoder
 *
 * Copyright (c) 2001-2007 by Sylvain Guerin (sylvain.guerin@denali.be)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by  the Free Software Foundation; either version 2.1 of the License or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 **************************************************************************/

package fr.enstb.xmlcode;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.Date;

/**
 * <p>
 * A KeyValue property represents a single-like property, accessible directly by
 * related field or related accessors.
 * </p>
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 * @see KeyValueCoder
 * @see KeyValueDecoder
 * 
 */
public class SingleKeyValueProperty extends KeyValueProperty
{

    /**
     * Creates a new <code>KeyValueProperty</code> instance, given an object.<br>
     * 
     * @param anObject
     *            an <code>Object</code> value
     * @param propertyName
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public SingleKeyValueProperty(Object anObject, String propertyName, boolean setMethodIsMandatory) throws InvalidKeyValuePropertyException
    {

        super(anObject, propertyName);
        init(propertyName, setMethodIsMandatory);
    }

    /**
     * Creates a new <code>KeyValueProperty</code> instance, given an object
     * class.<br>
     * To be usable, this property should be set with a correct object
     * (according to object class)
     * 
     * @param anObject
     *            an <code>Object</code> value
     * @param propertyName
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public SingleKeyValueProperty(Class anObjectClass, String propertyName, boolean setMethodIsMandatory) throws InvalidKeyValuePropertyException
    {

        super(anObjectClass, propertyName);
        init(propertyName, setMethodIsMandatory);
    }

    /**
     * Initialize this property, given a propertyName.<br>
     * This method is called during constructor invokation.
     */
    protected void init(String propertyName, boolean setMethodIsMandatory) throws InvalidKeyValuePropertyException
    {

        super.init(propertyName, setMethodIsMandatory);
    }

    /**
     * Returns boolean indicating if primitive (a primitive or a directely
     * string convertable object)
     */
    public boolean classIsPrimitive()
    {

        return ((getType().isPrimitive()) || (StringEncoder.isConvertable(getType())));
    }

    /**
     * Returns int value, asserting that this property represents an int
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>int</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     */
    public int getIntValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Integer returnedValue;
                try {
                    returnedValue = (Integer) getMethod.invoke(object, null);
                    return returnedValue.intValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not an int");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not an int");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    return field.getInt(object);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not an int");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns long value, asserting that this property represents an long
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>long</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public long getLongValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Long returnedValue;
                try {
                    returnedValue = (Long) getMethod.invoke(object, null);
                    return returnedValue.longValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a long");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a long");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    return field.getLong(object);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a long");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns short value, asserting that this property represents an long
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>short</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public short getShortValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Short returnedValue;
                try {
                    returnedValue = (Short) getMethod.invoke(object, null);
                    return returnedValue.shortValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a short");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a short");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    return field.getShort(object);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a short");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns char value, asserting that this property represents an char
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>char</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public char getCharValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Character returnedValue;
                try {
                    returnedValue = (Character) getMethod.invoke(object, null);
                    return returnedValue.charValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a char");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a char");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    return field.getChar(object);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a char");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns boolean value, asserting that this property represents an boolean
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>boolean</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public boolean getBooleanValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Boolean returnedValue;
                try {
                    returnedValue = (Boolean) getMethod.invoke(object, null);
                    return returnedValue.booleanValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a boolean");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a boolean");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    return field.getBoolean(object);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a boolean");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns byte value, asserting that this property represents an byte
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>byte</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public byte getByteValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Byte returnedValue;
                try {
                    returnedValue = (Byte) getMethod.invoke(object, null);
                    return returnedValue.byteValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a byte");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a byte");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    return field.getByte(object);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a byte");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns float value, asserting that this property represents a float
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>float</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public float getFloatValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Float returnedValue;
                try {
                    returnedValue = (Float) getMethod.invoke(object, null);
                    return returnedValue.floatValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a float");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {
                try {
                    return field.getFloat(object);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a float");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a float");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns double value, asserting that this property represents an double
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>double</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public double getDoubleValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (getMethod != null) {

                Double returnedValue;
                try {
                    returnedValue = (Double) getMethod.invoke(object, null);
                    return returnedValue.doubleValue();
                } catch (InvocationTargetException e) {
                    throw new AccessorInvocationException("Exception thrown while invoking: " + getMethod, e);
                } catch (ClassCastException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a double");
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a double");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    return field.getDouble(object);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a double");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Sets int value, asserting that this property represents an int property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            an <code>int</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setIntValue(int aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Integer setValue = new Integer(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not an int");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.setInt(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not an int");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets long value, asserting that this property represents an long property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>long</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setLongValue(long aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Long setValue = new Long(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a long");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.setLong(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a long");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets short value, asserting that this property represents an short
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            an <code>short</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setShortValue(short aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Short setValue = new Short(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a short");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.setShort(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a short");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets char value, asserting that this property represents an char property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>char</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setCharValue(char aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Character setValue = new Character(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a char");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.setChar(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a char");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets boolean value, asserting that this property represents an boolean
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>boolean</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setBooleanValue(boolean aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Boolean setValue = new Boolean(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a boolean");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {
                try {
                    field.setBoolean(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a boolean");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets byte value, asserting that this property represents an byte property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>byte</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setByteValue(byte aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Byte setValue = new Byte(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a byte");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {
                try {
                    field.setByte(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a byte");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets float value, asserting that this property represents a float
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>float</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setFloatValue(float aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Float setValue = new Float(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a float");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {
                try {
                    field.setFloat(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a float");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets double value, asserting that this property represents an double
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>double</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     * 
     */
    public void setDoubleValue(double aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Double setValue = new Double(aValue);
                Object params[] = new Object[1];
                params[0] = setValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a double");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + " Exception raised: "
                            + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.setDouble(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a double");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets String value, asserting that this property represents a String
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     */
    public void setStringValue(String aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Object params[] = new Object[1];
                params[0] = aValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a String");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.set(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a String");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets Date value, asserting that this property represents an Date property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>Date</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     */
    public void setDateValue(Date aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Object params[] = new Object[1];
                params[0] = aValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a Date");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.set(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a Date");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets File value, asserting that this property represents an File property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>File</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     */
    public void setFileValue(File aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Object params[] = new Object[1];
                params[0] = aValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a File");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.set(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a File");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets URL value, asserting that this property represents an URL property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>URL</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     */
    public void setURLValue(URL aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {

            if (setMethod != null) {

                Object params[] = new Object[1];
                params[0] = aValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("Exception thrown while invoking: " + setMethod, e);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a URL");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }

            }

            else if (field != null) {

                try {
                    field.set(object, aValue);
                } catch (IllegalArgumentException e) {
                    throw new InvalidKeyValuePropertyException("Argument type mismatch: " + getName() + " is not a URL");
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Returns int value, asserting that this property represents an int
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>int</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public int getIntValue(Object anObject)
    {

        setObject(anObject);
        return getIntValue();
    }

    /**
     * Returns long value, asserting that this property represents an long
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>long</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public long getLongValue(Object anObject)
    {

        setObject(anObject);
        return getLongValue();
    }

    /**
     * Returns short value, asserting that this property represents a short
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>short</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public short getShortValue(Object anObject)
    {

        setObject(anObject);
        return getShortValue();
    }

    /**
     * Returns char value, asserting that this property represents an char
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>char</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public char getCharValue(Object anObject)
    {

        setObject(anObject);
        return getCharValue();
    }

    /**
     * Returns boolean value, asserting that this property represents an boolean
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>boolean</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public boolean getBooleanValue(Object anObject)
    {

        setObject(anObject);
        return getBooleanValue();
    }

    /**
     * Returns byte value, asserting that this property represents an byte
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>byte</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public byte getByteValue(Object anObject)
    {

        setObject(anObject);
        return getByteValue();
    }

    /**
     * Returns float value, asserting that this property represents a float
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>float</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public float getFloatValue(Object anObject)
    {

        setObject(anObject);
        return getFloatValue();
    }

    /**
     * Returns double value, asserting that this property represents an double
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>double</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public double getDoubleValue(Object anObject)
    {

        setObject(anObject);
        return getDoubleValue();
    }

    /**
     * Sets int value, asserting that this property represents an int property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            an <code>int</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setIntValue(int aValue, Object anObject)
    {

        setObject(anObject);
        setIntValue(aValue);
    }

    /**
     * Sets long value, asserting that this property represents an long property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>long</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setLongValue(long aValue, Object anObject)
    {

        setObject(anObject);
        setLongValue(aValue);
    }

    /**
     * Sets short value, asserting that this property represents a short
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>short</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setShortValue(short aValue, Object anObject)
    {

        setObject(anObject);
        setShortValue(aValue);
    }

    /**
     * Sets char value, asserting that this property represents an char property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>char</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setCharValue(char aValue, Object anObject)
    {

        setObject(anObject);
        setCharValue(aValue);
    }

    /**
     * Sets boolean value, asserting that this property represents an boolean
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>boolean</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setBooleanValue(boolean aValue, Object anObject)
    {

        setObject(anObject);
        setBooleanValue(aValue);
    }

    /**
     * Sets byte value, asserting that this property represents an byte property
     * (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>byte</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setByteValue(byte aValue, Object anObject)
    {

        setObject(anObject);
        setByteValue(aValue);
    }

    /**
     * Sets float value, asserting that this property represents a float
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>float</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setFloatValue(float aValue, Object anObject)
    {

        setObject(anObject);
        setFloatValue(aValue);
    }

    /**
     * Sets double value, asserting that this property represents an double
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            a <code>double</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setDoubleValue(double aValue, Object anObject)
    {

        setObject(anObject);
        setDoubleValue(aValue);
    }

    /**
     * Return a string representation of this object (debug purposes)
     */
    public String toString()
    {
        return "Object: " + object + "\nField: " + field + "\nGetMethod: " + getMethod + "\nSetMethod: " + setMethod + "\nType: " + type;

    }

}
