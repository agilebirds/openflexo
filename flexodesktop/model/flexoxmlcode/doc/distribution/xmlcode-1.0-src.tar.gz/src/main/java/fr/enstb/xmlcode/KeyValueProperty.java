/**************************************************************************
 * KeyValueProperty.java
 *
 * XMLCoDe project - A free java implementation of an XML coder/decoder
 *
 * Copyright (c) 2001-2007 by Sylvain Guerin (sylvain.guerin@denali.be)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by  the Free Software Foundation; either version 2.1 of the License or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 **************************************************************************/

package fr.enstb.xmlcode;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.Vector;

/**
 * <p>
 * A KeyValue property represents a property, accessible directly by related
 * field or through accessors methods (get/set pair for single properties (see
 * {@link SingleKeyValueProperty}), addTo../removeFrom.. pair for vector-like
 * properties (see {@link VectorKeyValueProperty}), and
 * set...ForKey/remove...WithKey for hashtable-like properties
 * {@link HashtableKeyValueProperty}.
 * </p>
 * <p>
 * NB: to be valid, a KeyValueProperty object should be identified by at least
 * the field or accessors methods.
 * </p>
 * <p>
 * <b>Important note:</b>If related field exist (is public) and accessors
 * methods exists also, the operations are processed using accessors (field
 * won't be used directly).
 * </p>
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 * @see KeyValueCoder
 * @see KeyValueDecoder
 * 
 */
public abstract class KeyValueProperty
{

    /** Stores date format */
    public static String dateFormat = "yyyy.MM.dd G 'at' HH:mm:ss a zzz";

    /** Stores property's name */
    protected String name;

    /** Stores related object (could be null) */
    protected Object object;

    /** Stores related object'class */
    protected Class objectClass;

    /**
     * Stores related field (if this one is public) or null if field is
     * protected or non-existant
     */
    protected Field field;

    /** Stores related type (the class of related property) */
    protected Class type;

    /**
     * Stores related "get" method (if this one is public) or null if method is
     * protected or non-existant
     */
    protected Method getMethod;

    /**
     * Stores related "set" method (if this one is public) or null if method is
     * protected or non-existant
     */
    protected Method setMethod;

    /**
     * Creates a new <code>KeyValueProperty</code> instance, given an object.<br>
     * 
     * @param anObject
     *            an <code>Object</code> value
     * @param propertyName
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public KeyValueProperty(Object anObject, String propertyName) throws InvalidKeyValuePropertyException
    {

        super();
        object = anObject;
        objectClass = anObject.getClass();
    }

    /**
     * Creates a new <code>KeyValueProperty</code> instance, given an object
     * class.<br>
     * To be usable, this property should be set with a correct object
     * (according to object class)
     * 
     * @param anObject
     *            an <code>Object</code> value
     * @param propertyName
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public KeyValueProperty(Class anObjectClass, String propertyName) throws InvalidKeyValuePropertyException
    {

        super();
        object = null;
        objectClass = anObjectClass;
    }

    private Vector compoundKeyValueProperties;

    private boolean isCompound;

    /**
     * Initialize this property, given a propertyName.<br>
     * This method is called during constructor invokation. NB: to be valid, a
     * property should be identified by at least the field or the get/set
     * methods pair. If the field is accessible, and only the get or the set
     * method is accessible, a warning will be thrown.
     */
    protected void init(String propertyName, boolean setMethodIsMandatory) throws InvalidKeyValuePropertyException
    {
        String lastName;
        Class lastClass = null;

        name = propertyName;

        if (name.lastIndexOf(".") > -1) {
            isCompound = true;
            // System.out.println ("Register compound key-value property
            // "+propertyName);
            StringTokenizer st = new StringTokenizer(name, ".");
            String nextKey = st.nextToken();
            Class nextClass = objectClass;
            compoundKeyValueProperties = new Vector();
            while (st.hasMoreTokens()) {
                SingleKeyValueProperty skvp = new SingleKeyValueProperty(nextClass, nextKey, false);
                compoundKeyValueProperties.add(skvp);
                // System.out.println ("Register compound "+nextKey+" with
                // "+nextClass);
                nextKey = st.nextToken();
                nextClass = skvp.getType();
            }
            lastName = nextKey;
            lastClass = nextClass;
        } else {
            isCompound = false;
            lastName = propertyName;
            lastClass = objectClass;
        }

        String propertyNameWithFirstCharToUpperCase = lastName.substring(0, 1).toUpperCase() + lastName.substring(1, lastName.length());

        field = null;

        try {
            field = lastClass.getField(lastName);
        } catch (NoSuchFieldException e) {
            // Debugging.debug ("NoSuchFieldException, trying to find get/set
            // methods pair");
        } catch (SecurityException e) {
            // Debugging.debug ("SecurityException, trying to find get/set
            // methods pair");
        }

        getMethod = searchMatchingGetMethod(lastClass, lastName);

        if (field == null) {
            if (getMethod == null) {
                throw new InvalidKeyValuePropertyException("No public field " + lastName + " found, nor method matching " + lastName + "() nor " + "_"
                        + lastName + "() nor " + "get" + propertyNameWithFirstCharToUpperCase + "() nor " + "_get" + propertyNameWithFirstCharToUpperCase
                        + "() found in class:" + lastClass.getName());
            } else {
                type = getMethod.getReturnType();
            }
        } else { // field != null
            type = field.getType();
            if (getMethod != null) {
                if (getMethod.getReturnType() != type) {
                    Debugging.warn("Public field " + lastName + " found, with type " + type.getName() + " found " + " and method " + getMethod.getName()
                            + " found " + " declaring return type " + getMethod.getReturnType() + " Ignoring method...");
                    getMethod = null;
                }
            }
        }

        setMethod = searchMatchingSetMethod(lastClass, lastName, type);

        if (setMethodIsMandatory) {
            if (setMethod == null) {
                if (field == null) {
                    throw new InvalidKeyValuePropertyException("No public field " + lastName + " found, nor method matching " + "set"
                            + propertyNameWithFirstCharToUpperCase + "(" + type.getName() + ") or " + "_set" + propertyNameWithFirstCharToUpperCase + "("
                            + type.getName() + ") found " + "in class " + lastClass);
                } else {
                    if (getMethod != null) {
                        // Debugging.debug ("Public field "+propertyName+"
                        // found, with type "
                        // + type.getName()+ " found "
                        // + " and method "+getMethod.getName()+" found "
                        // + " but no method matching "
                        // +"set"+propertyNameWithFirstCharToUpperCase+"("+type.getName()+")
                        // or "
                        // +"_set"+propertyNameWithFirstCharToUpperCase+"("+type.getName()+")
                        // found."
                        // +" Will use directly the field to set values.");
                    }
                }
            }
        }

        if ((getMethod != null) && (setMethod != null)) {
            // If related field exist (is public) and accessors methods exists
            // also,
            // the operations are processed using accessors (field won't be used
            // directly,
            // and should be set to null).
            field = null;
        }

    }

    /**
     * Try to find a matching "get" method, such as (in order):
     * <ul>
     * <li>propertyName()</li>
     * <li>_propertyName()</li>
     * <li>getPropertyName()</li>
     * <li>_getPropertyName()</li>
     * </ul>
     * Returns corresponding method, null if no such method exist
     */
    protected Method searchMatchingGetMethod(Class lastClass, String propertyName)
    {

        Method returnedMethod;
        String propertyNameWithFirstCharToUpperCase = propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1, propertyName.length());

        Vector tries = new Vector();

        tries.add(propertyName);
        tries.add("_" + propertyName);
        tries.add("get" + propertyNameWithFirstCharToUpperCase);
        tries.add("_get" + propertyNameWithFirstCharToUpperCase);

        for (Enumeration e = tries.elements(); e.hasMoreElements();) {
            try {
                return lastClass.getMethod((String) e.nextElement(), null);
            } catch (SecurityException err) {
                // we continue
            } catch (NoSuchMethodException err) {
                // we continue
            }
        }

        // Debugging.debug ("No method matching "
        // +propertyName+"() or "
        // +"_"+propertyName+"() or "
        // +"get"+propertyNameWithFirstCharToUpperCase+"() or "
        // +"_get"+propertyNameWithFirstCharToUpperCase+"() found.");

        return null;

    }

    /**
     * Try to find a matching "set" method, such as (in order):
     * <ul>
     * <li>setPropertyName(Type)</li>
     * <li>_setPropertyName(Type)</li>
     * </ul>
     * Returns corresponding method, null if no such method exist
     */
    protected Method searchMatchingSetMethod(Class lastClass, String propertyName, Class aType)
    {

        Method returnedMethod;
        String propertyNameWithFirstCharToUpperCase = propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1, propertyName.length());

        Vector tries = new Vector();

        Class params[] = new Class[1];
        params[0] = aType;

        tries.add("set" + propertyNameWithFirstCharToUpperCase);
        tries.add("_set" + propertyNameWithFirstCharToUpperCase);

        for (Enumeration e = tries.elements(); e.hasMoreElements();) {
            try {
                return lastClass.getMethod((String) e.nextElement(), params);
            } catch (SecurityException err) {
                // we continue
            } catch (NoSuchMethodException err) {
                // we continue
            }
        }

        // Debugging.debug ("No method matching "
        // +"set"+propertyNameWithFirstCharToUpperCase+"("+type.getName()+") or
        // "
        // +"_set"+propertyNameWithFirstCharToUpperCase+"("+type.getName()+")
        // found.");

        return null;

    }

    /**
     * Stores related "get" method (if this one is public) or null if method is
     * protected/private or non-existant
     */
    public Method getGetMethod()
    {

        return getMethod;
    }

    /**
     * Stores related "set" method (if this one is public) or null if method is
     * protected/private or non-existant
     */
    public Method getSetMethod()
    {

        return setMethod;
    }

    /**
     * Returns name of this property
     */
    public String getName()
    {

        return name;
    }

    /**
     * Returns related object (could be null)
     */
    public Object getObject()
    {

        return object;
    }

    /**
     * Sets related object, asserting that the type is correct according to
     * property type
     */
    public void setObject(Object anObject)
    {

        if (objectClass.isAssignableFrom(anObject.getClass())) {
            object = anObject;
        } else {
            throw new InvalidKeyValuePropertyException("Invalid object type, expected: " + objectClass.getName());
        }
    }

    /**
     * Returns related object class (never null)
     */
    public Class getObjectClass()
    {

        return objectClass;
    }

    /**
     * Returns related field (if this one is public) or null if field is
     * protected or non-existant
     */
    public Field getField()
    {

        return field;
    }

    /**
     * Returns related type
     */
    public Class getType()
    {

        return type;
    }

    /**
     * Search and returns all methods (as {@link AccessorMethod} objects) of
     * related class whose names is in the specified string list, with exactly
     * the specified number of parameters, ascendant ordered regarding
     * parameters specialization.
     * 
     * @see AccessorMethod
     */
    protected TreeSet searchMethodsWithNameAndParamsNumber(String[] searchedNames, int paramNumber)
    {

        TreeSet returnedTreeSet = new TreeSet();
        Method[] allMethods = objectClass.getMethods();

        for (int i = 0; i < allMethods.length; i++) {
            Method tempMethod = allMethods[i];
            for (int j = 0; j < searchedNames.length; j++) {
                if ((tempMethod.getName().equalsIgnoreCase(searchedNames[j])) && (tempMethod.getParameterTypes().length == paramNumber)) {
                    // This is a good candidate
                    returnedTreeSet.add(new AccessorMethod(this, tempMethod));
                }
            }
        }
        // Debugging.debug ("Class "+objectClass.getName()+": found "
        // +returnedTreeSet.size()+" accessors:");
        // for (Iterator i = returnedTreeSet.iterator(); i.hasNext();) {
        // Debugging.debug ("> "+((AccessorMethod)i.next()).getMethod());
        // }
        return returnedTreeSet;
    }

    /**
     * Sets Object value, asserting that this property represents an Object
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            an <code>Object</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setObjectValue(Object aValue)
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {
            if (field != null) {
                try {
                    field.set(object, aValue);
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else if (setMethod != null) {

                Object params[] = new Object[1];
                params[0] = aValue;

                try {
                    setMethod.invoke(object, params);
                } catch (InvocationTargetException e) {
                    //e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("AccessorInvocationException: class " + getObjectClass().getName() + ": method "
                            + setMethod.getName() + " Exception raised: " + e.getTargetException().toString(), e);
                } catch (Exception e) {
                    // e.printStackTrace();
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + setMethod.getName() + " Exception raised: " + e.toString());
                }

            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor set method found !!!");
            }

        }
    }

    /**
     * Sets Object value, asserting that this property represents an Object
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            an <code>Object</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setObjectValue(Object aValue, Object anObject)
    {

        setObject(anObject);
        setObjectValue(aValue);
    }

    /**
     * Returns Object value, asserting that this property represents an Object
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>Object</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public Object getObjectValue()
    {

        if (object == null) {
            throw new InvalidKeyValuePropertyException("No object is specified");
        } else {
            Object currentObject = object;
            if (isCompound) {
                for (Enumeration e = compoundKeyValueProperties.elements(); e.hasMoreElements();) {
                    if (currentObject != null) {
                        currentObject = ((SingleKeyValueProperty) e.nextElement()).getObjectValue(currentObject);
                    }
                }
                if (currentObject == null) {
                    return null;
                }
            }

            if (field != null) {
                try {
                    return field.get(currentObject);
                } catch (Exception e) {
                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": field "
                            + field.getName() + " Exception raised: " + e.toString());
                }
            }

            else if (getMethod != null) {

                try {
                    return getMethod.invoke(currentObject, null);
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                    throw new AccessorInvocationException("AccessorInvocationException: class " + getObjectClass().getName() + ": method "
                            + getMethod.getName() + " Exception raised: " + e.getTargetException().toString(), e);
                } catch (Exception e) {

                    throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: class " + getObjectClass().getName() + ": method "
                            + getMethod.getName() + " Exception raised: " + e.toString());
                }

            }

            else {
                throw new InvalidKeyValuePropertyException("InvalidKeyValuePropertyException: no field nor get method found !!!");
            }

        }
    }

    /**
     * Returns Object value, asserting that this property represents an Object
     * property (if not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @return an <code>Object</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public Object getObjectValue(Object anObject)
    {

        setObject(anObject);
        return getObjectValue();
    }

}
