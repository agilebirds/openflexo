/**************************************************************************
 * PropertiesKeyValueProperty.java
 *
 * XMLCoDe project - A free java implementation of an XML coder/decoder
 *
 * Copyright (c) 2001-2007 by Sylvain Guerin (sylvain.guerin@denali.be)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by  the Free Software Foundation; either version 2.1 of the License or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 **************************************************************************/
package fr.enstb.xmlcode;

/**
 * <p>
 * A PropertiesKeyValueProperty property represents a hashtable-like property,
 * accessible directly by related field or related accessors: this property
 * matches a dynamic list of objects stored in a {@link java.util.Hashtable} or
 * a sub-class of {@link java.util.Hashtable} where key is a String obtained and
 * parsed from/as XML element name: therefore, there is no need to implement
 * model for contained data
 * </p>
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 * @see KeyValueCoder
 * @see KeyValueDecoder
 * 
 */
public class PropertiesKeyValueProperty extends HashtableKeyValueProperty
{

    /**
     * Creates a new <code>PropertiesKeyValueProperty</code> instance, given
     * an object.<br>
     * 
     * @param anObject
     *            an <code>Object</code> value
     * @param propertyName
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public PropertiesKeyValueProperty(Object anObject, String propertyName, boolean setMethodIsMandatory) throws InvalidKeyValuePropertyException
    {

        super(anObject, propertyName, setMethodIsMandatory);
        init(propertyName, setMethodIsMandatory);
    }

    /**
     * Creates a new <code>PropertiesKeyValueProperty</code> instance, given
     * an object class.<br>
     * To be usable, this property should be set with a correct object
     * (according to object class)
     * 
     * @param anObject
     *            an <code>Object</code> value
     * @param propertyName
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public PropertiesKeyValueProperty(Class anObjectClass, String propertyName, boolean setMethodIsMandatory) throws InvalidKeyValuePropertyException
    {

        super(anObjectClass, propertyName, setMethodIsMandatory);
        init(propertyName, setMethodIsMandatory);
    }

    /**
     * Add Object value, asserting that this property represents a
     * Properties-like property (if not, throw an
     * InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            an <code>Object</code> value
     * @param aKey
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     */
    public void setObjectValueForKey(Object aValue, String aKey)
    {
        super.setObjectValueForKey(aValue, aKey);
    }

    /**
     * Add Object value for considered object <code>anObject</code>,
     * asserting that this property represents a Properties-like property (if
     * not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aValue
     *            an <code>Object</code> value
     * @param aKey
     *            a <code>String</code> value
     * @param anObject
     *            an <code>Object</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void setObjectValueForKey(Object aValue, String aKey, Object anObject)
    {
        super.setObjectValueForKey(aValue, aKey, anObject);
    }

    /**
     * Remove Object value, asserting that this property represents a
     * Properties-like property (if not, throw an
     * InvalidKeyValuePropertyException exception)
     * 
     * @param aKey
     *            a <code>String</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     * @exception AccessorInvocationException
     *                if an error occurs during accessor invocation
     */
    public void removeWithKeyValue(String aKey)
    {
        super.removeWithKeyValue(aKey);
    }

    /**
     * Remove Object value for considered object <code>anObject</code>,
     * asserting that this property represents a Properties-like property (if
     * not, throw an InvalidKeyValuePropertyException exception)
     * 
     * @param aKey
     *            a <code>String</code> value
     * @param anObject
     *            an <code>Object</code> value
     * @exception InvalidKeyValuePropertyException
     *                if an error occurs
     */
    public void removeWithKeyValue(String aKey, Object anObject)
    {
        super.removeWithKeyValue(aKey, anObject);
    }

}
