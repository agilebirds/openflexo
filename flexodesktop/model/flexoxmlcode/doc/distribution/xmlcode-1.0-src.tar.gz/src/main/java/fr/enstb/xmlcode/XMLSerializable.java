/**************************************************************************
 * XMLSerializable.java
 *
 * XMLCoDe project - A free java implementation of an XML coder/decoder
 *
 * Copyright (c) 2001-2007 by Sylvain Guerin (sylvain.guerin@denali.be)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by  the Free Software Foundation; either version 2.1 of the License or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 **************************************************************************/

package fr.enstb.xmlcode;

/**
 * <p>
 * Classes implementing interface <code>XMLSerializable</code> could be
 * instancied and coded from/to XML strings and streams.
 * </p>
 * No special behaviour has to be implemented in your
 * <code>XMLSerializable</code> objects, since it is done via an externaly
 * defined mapping (see {@link  fr.enstb.xmlcode.XMLMapping}). This interface
 * just help the programmer to remember that this class xml serialization MUST
 * be described somewhere.<br>
 * <b>Note that it means that you can encode/decode into/from XML all types of
 * classes</b>, since you just have to declare those classes as implementing
 * this interface..
 * 
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public interface XMLSerializable
{

} /* end interface XMLSerializable */
