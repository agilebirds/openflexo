/**************************************************************************
 * Debugging.java
 *
 * XMLCoDe project - A free java implementation of an XML coder/decoder
 *
 * Copyright (c) 2001-2007 by Sylvain Guerin (sylvain.guerin@denali.be)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by  the Free Software Foundation; either version 2.1 of the License or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 **************************************************************************/

package fr.enstb.xmlcode;

/**
 * <p>
 * Utility class providing debugging facilities
 * </p>
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Debugging
{

    /** Flag indicating if debug should be displayed or not */
    protected static boolean debugEnabled = false;

    /**
     * Enable debug
     */
    public static void enableDebug()
    {

        debugEnabled = true;
    }

    /**
     * Disable debug
     */
    public static void disableDebug()
    {

        debugEnabled = false;
    }

    /**
     * Prints to stdout specified string, if debug was enabled
     */
    public static void debug(String aDebugString)
    {

        if (debugEnabled) {
            System.out.println(aDebugString);
        }

    }

    /**
     * Prints to stderr specified string as a warning
     */
    public static void warn(String aWarningMessage)
    {

        System.err.println("!!! WARNING !!!");
        System.err.println("Message:\n" + aWarningMessage);
        System.err.println("StackTrace:\n");
        (new RuntimeException()).printStackTrace();

    }

}
