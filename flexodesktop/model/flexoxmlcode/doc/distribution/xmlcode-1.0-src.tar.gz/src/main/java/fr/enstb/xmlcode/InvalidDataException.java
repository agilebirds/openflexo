/**************************************************************************
 * InvalidDataException.java
 *
 * XMLCoDe project - A free java implementation of an XML coder/decoder
 *
 * Copyright (c) 2001-2007 by Sylvain Guerin (sylvain.guerin@denali.be)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by  the Free Software Foundation; either version 2.1 of the License or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 **************************************************************************/

package fr.enstb.xmlcode;

/**
 * <p>
 * Exception thrown when trying to decode an object from invalid data regarding
 * a given mapping or model file. The 'message' (see {@link #getMessage()})
 * contains the error description. Those exceptions are raised during String
 * encoding/decoding
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class InvalidDataException extends RuntimeException
{

    /**
     * Creates a new <code>InvalidDataException</code> instance.
     * 
     */
    public InvalidDataException()
    {
        super();
    }

    /**
     * Creates a new <code>InvalidDataException</code> instance, given a
     * message <code>aMessage</code>
     * 
     * @param aMessage
     *            a <code>String</code> value
     */
    public InvalidDataException(String aMessage)
    {
        super(aMessage);
    }
}
