/**************************************************************************
 /* CommandsList.java
 /*
 /* XMLCoDe project - A free java implementation of an XML coder/decoder
 /*
 /* Copyright (c) 2001-2002 by Sylvain Guerin (Sylvain.Guerin@enst-bretagne.fr)
 /*
 /* This sample program is placed into the public domain and can be
 /* used or modified without any restriction.
 /*
 /* This program is distributed in the hope that it will be useful, but
 /* WITHOUT ANY WARRANTY; without even the implied warranty of
 /* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 /**************************************************************************/

package fr.enstb.xmlcode.examples.example2;

import java.util.Enumeration;
import java.util.Hashtable;

/**
 * Class <code>CommandsList</code> is intented to represent a list of commands
 * stored in a hashtable where key is a CommandIdentifier object.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class CommandsList extends Hashtable
{

    private SellReport relatedSellReport;

    protected int commandsNumber;

    public CommandsList()
    {
        super();
        commandsNumber = 0;
    }

    public Object get(Object key)
    {
        return super.get(key);
    }

    public Object put(Object /* CommandIdentifier */key, Command value)
    {
        if (relatedSellReport != null) {
            value.setRelatedSellReport(relatedSellReport);
        }
        commandsNumber++;
        return super.put(key, value);
    }

    public Object put(Object key, Object value)
    {
        System.out.println("Sorry, this object should only store " + "CommandIdentifier/Command key/object pair.");
        System.out.println("key = " + key + " class = " + key.getClass().getName());
        System.out.println("value = " + value + " class = " + value.getClass().getName());
        return null;
    }

    public Object remove(CommandIdentifier key)
    {
        Command value = (Command) get(key);
        if (relatedSellReport != null) {
            value.setRelatedSellReport(null);
        }
        commandsNumber--;
        return super.remove(key);
    }

    public Object remove(Object key)
    {
        System.out.println("Sorry, this object should only store " + "CommandIdentifier/Command key/object pair.");
        return null;
    }

    public void setRelatedSellReport(SellReport aSellReport)
    {
        relatedSellReport = aSellReport;
        if (size() > 0) {
            for (Enumeration e = elements(); e.hasMoreElements();) {
                ((Command) e.nextElement()).setRelatedSellReport(aSellReport);
            }
        }

    }

    public String toString()
    {
        String returnedString = "CommandsList (" + size() + " commands)\n";

        if (size() > 0) {
            for (Enumeration e = keys(); e.hasMoreElements();) {
                Object key = e.nextElement();
                returnedString += "[" + key + "] " + get(key);
            }
        }
        return returnedString;
    }

}
