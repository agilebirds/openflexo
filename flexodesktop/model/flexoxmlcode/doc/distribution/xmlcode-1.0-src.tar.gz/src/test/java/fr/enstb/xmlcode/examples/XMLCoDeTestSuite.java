/*
 * Created on 11 janv. 2006 by sguerin
 *
 * Flexo Application Suite
 * (c) Denali 2003-2005
 */

package fr.enstb.xmlcode.examples;

import junit.framework.Test;
import junit.framework.TestSuite;
import fr.enstb.xmlcode.examples.example1.Example1Test;
import fr.enstb.xmlcode.examples.example2.Example2Test;
import fr.enstb.xmlcode.examples.example3.Example3Test;
import fr.enstb.xmlcode.examples.example4.Example4Test;
import fr.enstb.xmlcode.examples.example5.Example5Test;

public class XMLCoDeTestSuite {

    public static Test suite() {
        TestSuite suite = new TestSuite("Tests for XMLCoDe library");
        
        //$JUnit-BEGIN$
        suite.addTestSuite(Example1Test.class);
        suite.addTestSuite(Example2Test.class);
        suite.addTestSuite(Example3Test.class);
        suite.addTestSuite(Example4Test.class);
        suite.addTestSuite(Example5Test.class);
         //$JUnit-END$
        return suite;
    }

}
