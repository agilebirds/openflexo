/*
 * Created on 11 janv. 2006 by sguerin
 *
 * Flexo Application Suite
 * (c) Denali 2003-2005
 */
package fr.enstb.xmlcode.examples.example4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import junit.framework.TestCase;
import fr.enstb.xmlcode.Debugging;
import fr.enstb.xmlcode.XMLCoder;
import fr.enstb.xmlcode.XMLDecoder;
import fr.enstb.xmlcode.XMLMapping;
import fr.enstb.xmlcode.XMLSerializable;

/**
 * <p>
 * Class <code>Example4</code> is intented to show an example of xml
 * coding/decoding scheme
 * </p>
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 * @see XMLCoder
 * @see XMLDecoder
 * @see XMLMapping
 */
public class Example4Test extends TestCase {

    private static final String path = System.getProperty("user.dir") + "/src/test/resources/example4/";
    private static final File exampleModelFile = new File(path+"ExampleModel.xml");
    private static final File dataFile = new File(path+"ExampleGraph.xml");
    private static final File resultFile = new File(path+"ResultGraph.xml");
    
    private String xmlData = "";
    private XMLMapping aMapping;
 
    public Example4Test(String name) 
    {
        super(name);
    }

    protected void setUp() throws Exception 
    {
        super.setUp();
        
        Debugging.disableDebug();

        if (!exampleModelFile.exists()) {
            fail("File " + exampleModelFile.getAbsolutePath() + " doesn't exist. Maybe you have to check your paths ?");
        }

        if (!dataFile.exists()) {
            fail("File " + dataFile.getName() + " doesn't exist. Maybe you have to check your paths ?");
        }
        
        FileInputStream in;
        byte[] buffer;

        try {
            in = new FileInputStream(dataFile);
            buffer = new byte[in.available()];
            in.read(buffer);
            xmlData = new String(buffer);
            in.close();
        } catch (Exception e) {
            fail(e.getMessage());
        }

        XMLCoder.setTransformerFactoryClass("org.apache.xalan.processor.TransformerFactoryImpl");
    }

    protected void tearDown() throws Exception 
    {
        super.tearDown();
     }

    public void test1()
    {
        try {
            Graph graph;
            String result;
            FileOutputStream out;

            aMapping = new XMLMapping(exampleModelFile);
            System.out.println("Reading, parsing and getting following model:\n" + aMapping.toString());

            GraphBuilder gb = new GraphBuilder();
            graph = (Graph) XMLDecoder.decodeObjectWithMapping(new FileInputStream(dataFile), aMapping, gb);
            System.out.println("Obtaining by parsing stream: " + graph.toString());

            System.out.print(gb.toString());

            result = XMLCoder.encodeObjectWithMapping((XMLSerializable) graph, aMapping);
            System.out.println("Coding to XML and getting " + result);

            out = new FileOutputStream(resultFile);
            XMLCoder.encodeObjectWithMapping((XMLSerializable) graph, aMapping, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            fail (e.getMessage());
        } 
    }

    public void test2()
    {
        try {
            Graph graph;
            String result;
            FileOutputStream out;

            graph = buildNewGraph();
            // Debugging.enableDebug();

            aMapping = new XMLMapping(exampleModelFile);
            System.out.println("Reading, parsing and getting following model:\n" + aMapping.toString());

             result = XMLCoder.encodeObjectWithMapping((XMLSerializable) graph, aMapping);
            System.out.println("Coding to XML and getting " + result);

            out = new FileOutputStream(resultFile);
            XMLCoder.encodeObjectWithMapping((XMLSerializable) graph, aMapping, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            fail (e.getMessage());
        } 
   }

    public static Graph buildNewGraph()
    {
        GraphBuilder gb = new GraphBuilder();
        Graph newGraph = new Graph(gb);
        Node node1 = new Node(gb);
        Node node2 = new Node(gb);
        Node node3 = new Node(gb);
        Node node4 = new Node(gb);
        Edge edge1 = new Edge(gb, node1, node2);
        Edge edge2 = new Edge(gb, node1, node3);
        Edge edge3 = new Edge(gb, node2, node3);
        Edge edge4 = new Edge(gb, node2, node4);
        Edge edge5 = new Edge(gb, node3, node4);
        newGraph.startNode = node1;
        return newGraph;
    }

    
}
