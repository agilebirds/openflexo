/*
 * Created on Jan 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package fr.enstb.xmlcode.examples.example4;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>Edge</code> is intented to represent an oriented edge object in
 * XML coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Edge implements XMLSerializable
{

    public Node originNode;

    public Node destinationNode;

    public Edge(GraphBuilder gb)
    {
        super();
        gb.edges.add(this);
    }

    public Edge(GraphBuilder gb, Node origin, Node destination)
    {
        super();
        originNode = origin;
        destinationNode = destination;
        origin.edges.add(this);
        gb.edges.add(this);
    }

    public String toString()
    {
        String returned = " [ Edge: ";
        returned += (originNode == null ? null : originNode.toShortString()) + "-";
        returned += (destinationNode == null ? null : destinationNode.toShortString()) + " ] ";
        return returned;
    }

    public void finalizeEdgeSerialization()
    {
        System.out.println("finalizeEdgeSerialization");
    }
}
