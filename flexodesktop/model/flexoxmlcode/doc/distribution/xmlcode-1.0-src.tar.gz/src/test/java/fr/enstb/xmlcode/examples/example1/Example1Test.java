/*
 * Created on 11 janv. 2006 by sguerin
 *
 * Flexo Application Suite
 * (c) Denali 2003-2005
 */
package fr.enstb.xmlcode.examples.example1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import junit.framework.TestCase;
import fr.enstb.xmlcode.Debugging;
import fr.enstb.xmlcode.XMLCoder;
import fr.enstb.xmlcode.XMLDecoder;
import fr.enstb.xmlcode.XMLMapping;
import fr.enstb.xmlcode.XMLSerializable;

/**
 * <p>
 * Class <code>Example1</code> is intented to show an example of xml
 * coding/decoding scheme
 * </p>
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 * @see XMLCoder
 * @see XMLDecoder
 * @see XMLMapping
 */
public class Example1Test extends TestCase {

    private static final String path = System.getProperty("user.dir") + "/src/test/resources/example1/";
    private static final File exampleModelFile = new File(path+"ExampleModel.xml");
    private static final File dataFile = new File(path+"ExampleCommand.xml");
    private static final File resultFile = new File(path+"ResultCommand.xml");
    
    private String xmlData = "";
    private XMLMapping aMapping;
    private Command myCommand;
    private Role onlyForCompilingProcess;

    public Example1Test(String name) 
    {
        super(name);
    }

    protected void setUp() throws Exception 
    {
        super.setUp();
        
        Debugging.disableDebug();

        if (!exampleModelFile.exists()) {
            fail("File " + exampleModelFile.getAbsolutePath() + " doesn't exist. Maybe you have to check your paths ?");
        }

        if (!dataFile.exists()) {
            fail("File " + dataFile.getName() + " doesn't exist. Maybe you have to check your paths ?");
        }
        
        FileInputStream in;
        byte[] buffer;

        try {
            in = new FileInputStream(dataFile);
            buffer = new byte[in.available()];
            in.read(buffer);
            xmlData = new String(buffer);
            in.close();
        } catch (Exception e) {
            fail(e.getMessage());
        }

        XMLCoder.setTransformerFactoryClass("org.apache.xalan.processor.TransformerFactoryImpl");
    }

    protected void tearDown() throws Exception 
    {
        super.tearDown();
     }

    public void test1()
    {
        try {
            Object anObject;
            String result;
            FileOutputStream out;

            aMapping = new XMLMapping(exampleModelFile);
            System.out.println("Reading, parsing and getting following model:\n" + aMapping.toString());
            System.out.println("Reading data file:\n" + xmlData);

            anObject = XMLDecoder.decodeObjectWithMapping(xmlData, aMapping);
            System.out.println("Obtaining by parsing string: " + anObject.toString());

            anObject = XMLDecoder.decodeObjectWithMapping(new FileInputStream(dataFile), aMapping);
            System.out.println("Obtaining by parsing stream: " + anObject.toString());

            result = XMLCoder.encodeObjectWithMapping((XMLSerializable) anObject, aMapping);
            System.out.println("Coding to XML and getting " + result);

            out = new FileOutputStream(resultFile);
            XMLCoder.encodeObjectWithMapping((XMLSerializable) anObject, aMapping, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            fail (e.getMessage());
        } 
    }

}
