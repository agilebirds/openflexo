/*
 * Created on Jan 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package fr.enstb.xmlcode.examples.example5;

import java.util.Enumeration;
import java.util.Vector;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>PreCondition</code> is intented to represent an oriented edge object in
 * XML coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class PreCondition implements XMLSerializable
{

    public Node attachedNode;
    public Vector incomingEdges;

    public int identifier;

    public PreCondition()
    {
        super();
        attachedNode = null;
        incomingEdges = new Vector();
    }

    public PreCondition(int anIdentifier, Node node)
    {
        this();
        attachedNode = node;
        attachedNode.preConditions.add(this);
        identifier = anIdentifier;
    }

    public String toShortString()
    {
        return "PreCondition:" + identifier;
    }

   public String toString()
    {
        String returned = " [ PreCondition "+identifier+" attached to node id ";
        returned += (attachedNode == null ? -1 : attachedNode.identifier) + " receiving edges : ";
        boolean isFirst = true;
        for (Enumeration en=incomingEdges.elements(); en.hasMoreElements();) {
            Edge edge = (Edge)en.nextElement();
            returned += (isFirst?"":",")+edge.identifier;
            isFirst = false;
        }
        returned += " ]";
        return returned;
    }

}
