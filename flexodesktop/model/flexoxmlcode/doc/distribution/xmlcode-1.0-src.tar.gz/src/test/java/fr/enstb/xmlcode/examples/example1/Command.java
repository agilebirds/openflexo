/**************************************************************************
 /* Command.java
 /*
 /* XMLCoDe project - A free java implementation of an XML coder/decoder
 /*
 /* Copyright (c) 2001-2002 by Sylvain Guerin (Sylvain.Guerin@enst-bretagne.fr)
 /*
 /* This sample program is placed into the public domain and can be
 /* used or modified without any restriction.
 /*
 /* This program is distributed in the hope that it will be useful, but
 /* WITHOUT ANY WARRANTY; without even the implied warranty of
 /* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 /**************************************************************************/

package fr.enstb.xmlcode.examples.example1;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>Command</code> is intented to represent a command object in XML
 * coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Command implements XMLSerializable
{

    private int qty;

    public boolean commandIsAlreadyPaid;

    private Movie movie;

    public Customer customer;

    public String toString()
    {
        String returnedString = "Command (qty=" + qty + ", paid=" + commandIsAlreadyPaid;
        if (movie != null) {
            returnedString += "," + movie.toString();
        }
        if (customer != null) {
            returnedString += "," + customer.toString();
        }
        returnedString += ")\n";
        return returnedString;
    }

    public int getQty()
    {
        return qty;
    }

    public void setQty(int aQty)
    {

        qty = aQty;
    }

    public Movie getMovie()
    {

        return movie;
    }

    public void setMovie(Movie aMovie)
    {

        movie = aMovie;
    }

}
