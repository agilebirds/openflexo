/**************************************************************************
 /* Vendor.java
 /*
 /* XMLCoDe project - A free java implementation of an XML coder/decoder
 /*
 /* Copyright (c) 2001-2002 by Sylvain Guerin (Sylvain.Guerin@enst-bretagne.fr)
 /*
 /* This sample program is placed into the public domain and can be
 /* used or modified without any restriction.
 /*
 /* This program is distributed in the hope that it will be useful, but
 /* WITHOUT ANY WARRANTY; without even the implied warranty of
 /* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 /**************************************************************************/

package fr.enstb.xmlcode.examples.example2;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>Vendor</code> is intented to represent a vendor
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Vendor extends Person implements XMLSerializable
{

    public int vendorId;

    public String toString()
    {
        return "Vendor(name=" + name + ", fistName=" + firstName + ", address=" + address + ")";
    }
}
