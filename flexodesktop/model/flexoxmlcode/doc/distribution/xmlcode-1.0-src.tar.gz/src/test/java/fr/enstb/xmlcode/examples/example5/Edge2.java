/*
 * Created on Jan 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package fr.enstb.xmlcode.examples.example5;


/**
 * Class <code>Edge</code> is intented to represent an oriented edge object in
 * XML coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Edge2 extends Edge
{

    public Node originNode;
    public PreCondition destinationPreCondition;

    public int identifier;

    public Edge2()
    {
        super();
    }

    public Edge2(int anIdentifier, Node origin, PreCondition destination)
    {
        super(anIdentifier,origin,destination);
    }

    public String shortClassName()
    {
        return "Edge2";
    }

}
