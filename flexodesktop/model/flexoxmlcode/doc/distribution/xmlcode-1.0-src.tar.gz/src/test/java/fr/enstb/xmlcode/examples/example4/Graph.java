/*
 * Created on Jan 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package fr.enstb.xmlcode.examples.example4;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>Graph</code> is intented to represent a graph object in XML
 * coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Graph implements XMLSerializable
{

    public Graph(GraphBuilder gb)
    {
        super();
    }

    public Node startNode;

    public void finalizeGraphSerialization(GraphBuilder gb)
    {
        System.out.println("finalizeGraphSerialization");
    }
}
