/**************************************************************************
 /* Foo.java
 /*
 /* XMLCoDe project - A free java implementation of an XML coder/decoder
 /*
 /* Copyright (c) 2001-2002 by Sylvain Guerin (Sylvain.Guerin@enst-bretagne.fr)
 /*
 /* This sample program is placed into the public domain and can be
 /* used or modified without any restriction.
 /*
 /* This program is distributed in the hope that it will be useful, but
 /* WITHOUT ANY WARRANTY; without even the implied warranty of
 /* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 /**************************************************************************/

package fr.enstb.xmlcode.examples.example3;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>Foo</code> is intented to represent a command object in XML
 * coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Foo implements XMLSerializable
{

    public int intField;

    public String stringField;

    public String toString()
    {

        return "Foo (" + intField + "," + stringField + ")";
    }
}
