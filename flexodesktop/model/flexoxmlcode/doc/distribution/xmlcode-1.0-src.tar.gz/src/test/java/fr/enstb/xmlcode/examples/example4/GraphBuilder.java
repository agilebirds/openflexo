/*
 * Created on Jan 18, 2005 by sguerin
 *
 * Flexo Application Suite
 * (c) Denali 2003-2005
 */
package fr.enstb.xmlcode.examples.example4;

import java.util.Enumeration;
import java.util.Vector;

/**
 * Please comment this class
 * 
 * @author sguerin
 * 
 */
public class GraphBuilder
{

    public Vector nodes = new Vector();

    public Vector edges = new Vector();

    public String toString()
    {
        String returned = "";
        for (Enumeration e = nodes.elements(); e.hasMoreElements();) {
            returned += ((Node) e.nextElement()).toString() + "\n";
        }
        for (Enumeration e = edges.elements(); e.hasMoreElements();) {
            returned += ((Edge) e.nextElement()).toString() + "\n";
        }
        return returned;
    }
}
