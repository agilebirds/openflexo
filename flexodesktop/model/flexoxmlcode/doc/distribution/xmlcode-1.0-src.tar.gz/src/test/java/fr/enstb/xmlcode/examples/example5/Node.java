/*
 * Created on Jan 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package fr.enstb.xmlcode.examples.example5;

import java.util.Enumeration;
import java.util.Vector;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>Node</code> is intented to represent a graph's node object in
 * XML coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class Node implements XMLSerializable
{

    public Vector preConditions;
    public Vector outgoingEdges;
    public Graph graph;

    public int identifier;

    public Node()
    {
        super();
         outgoingEdges = new Vector();
        preConditions = new Vector();
    }

    public Node(int anIdentifier, Graph aGraph)
    {
        this();
        identifier = anIdentifier;
        graph = aGraph;
        graph.nodes.add(this);
    }

    public String toShortString()
    {
        return "Node:" + identifier;
    }

    public String toString()
    {
        String returned = toShortString() + "\n";
        for (Enumeration e = preConditions.elements(); e.hasMoreElements();) {
            returned += e.nextElement().toString()+"\n";
        }
        for (Enumeration e = outgoingEdges.elements(); e.hasMoreElements();) {
            returned += e.nextElement().toString()+"\n";
        }
        return returned;
    }

}
