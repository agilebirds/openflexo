/*
 * Created on Jan 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package fr.enstb.xmlcode.examples.example5;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>Edge</code> is intented to represent an oriented edge object in
 * XML coding/decoding example.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public abstract class Edge implements XMLSerializable
{

    public Node originNode;
    public PreCondition destinationPreCondition;

    public int identifier;

    public Edge()
    {
        super();
        originNode = null;
        destinationPreCondition = null;
    }

    public Edge(int anIdentifier, Node origin, PreCondition destination)
    {
        this();
        originNode = origin;
        destinationPreCondition = destination;
        origin.outgoingEdges.add(this);
        destination.incomingEdges.add(this);
        identifier = anIdentifier;
    }

    public String toString()
    {
        String returned = " [ "+shortClassName()+": "+identifier+" from ";
        returned += (originNode == null ? null : originNode.toShortString()) + " to ";
        returned += (destinationPreCondition == null ? null : destinationPreCondition.toShortString()) + " ] ";
        return returned;
    }

    public abstract String shortClassName();
}
