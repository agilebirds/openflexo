/**************************************************************************
 /* SellReport.java
 /*
 /* XMLCoDe project - A free java implementation of an XML coder/decoder
 /*
 /* Copyright (c) 2001-2002 by Sylvain Guerin (Sylvain.Guerin@enst-bretagne.fr)
 /*
 /* This sample program is placed into the public domain and can be
 /* used or modified without any restriction.
 /*
 /* This program is distributed in the hope that it will be useful, but
 /* WITHOUT ANY WARRANTY; without even the implied warranty of
 /* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 /**************************************************************************/

package fr.enstb.xmlcode.examples.example2;

import fr.enstb.xmlcode.XMLSerializable;

/**
 * Class <code>SellReport</code> is intented to represent a sellers' month
 * report.
 * 
 * @author <a href="mailto:Sylvain.Guerin@enst-bretagne.fr">Sylvain Guerin</a>
 */
public class SellReport implements XMLSerializable
{

    // Serialized fields
    protected Vendor vendor;

    protected CommandsList commands;

    // Computed fields
    protected float totalAmount;

    protected float totalPaidAmount;

    protected float totalUnpaidAmount;

    public String toString()
    {
        String returnedString = "SellReport (totalAmount=" + totalAmount + ", totalPaidAmount=" + totalPaidAmount + ", totalUnpaidAmount=" + totalUnpaidAmount;
        if (vendor != null) {
            returnedString += ", vendor=" + vendor.toString();
        }
        returnedString += "\n";
        if (commands != null) {
            returnedString += commands.toString();
        }
        return returnedString;
    }

    public CommandsList getCommands()
    {
        return commands;
    }

    public void setCommands(CommandsList v)
    {
        commands = v;
        v.setRelatedSellReport(this);
    }

    public Vendor getVendor()
    {
        return vendor;
    }

    public void setVendor(Vendor v)
    {
        vendor = v;
    }

    public void setCommandForKey(Object aCommand, Object aKey)
    {
        System.out.println("setCommandForKey(Object,Object)");
        commands.put(aKey, aCommand);
    }

    public void setCommandForKey(Command aCommand, Object aKey)
    {
        System.out.println("setCommandForKey(Command,Object)");
        commands.put(aKey, aCommand);
    }

    public void setCommandForKey(Command aCommand, CommandIdentifier aKey)
    {
        System.out.println("setCommandForKey(Command,CommandIdentifier)");
        commands.put(aKey, aCommand);
    }

    public void removeCommandWithKey(Object aKey)
    {
        System.out.println("removeCommandWithKey(Object)");
        commands.remove(aKey);
    }

    public void removeCommandWithKey(CommandIdentifier aKey)
    {
        System.out.println("removeCommandWithKey(CommandIdentifier)");
        commands.remove(aKey);
    }

    public float getTotalAmount()
    {
        return totalAmount;
    }

    public void addToTotalAmount(float value)
    {
        totalAmount += value;
    }

    public void removeFromTotalAmount(float value)
    {
        totalAmount -= value;
    }

    public float getPaidAmount()
    {
        return totalPaidAmount;
    }

    public void addToPaidAmount(float value)
    {
        totalPaidAmount += value;
    }

    public void removeFromPaidAmount(float value)
    {
        totalPaidAmount -= value;
    }

    public float getUnpaidAmount()
    {
        return totalUnpaidAmount;
    }

    public void addToUnpaidAmount(float value)
    {
        totalUnpaidAmount += value;
    }

    public void removeFromUnpaidAmount(float value)
    {
        totalUnpaidAmount -= value;
    }

}
