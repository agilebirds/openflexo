function Log(className) {
	this.logDebugEnabled=false;
	this.logInfoEnabled=true;
	this.logged=className;
}

Log.prototype.info = function(message) {
		if(this.logInfoEnabled)
			alert(message);
}

Log.prototype.debug = function(message) {
		if(this.logDebugEnabled)
			alert(message);
}


	
function exactMatchPattern(string) {
	if (string != null && (string.match(/^\w*:/) || string.indexOf('?') >= 0 || string.indexOf('*') >= 0)) {
		return "exact:" + string;
	} else {
		return string;
	}
}