
/* We add a handler for images in lists. */
LocatorBuilders.add('imgTitleId', function(e) {
		if (e.nodeName == 'IMG') {
			if (e.getAttribute('id') && (e.getAttribute('title') || e.getAttribute('alt'))) {
				var id = e.getAttribute('id');
				if (e.getAttribute('title')) {
					return "//img[@id='"+id+"' and contains(@title,'" + e.getAttribute('title').replace(/^\s+/,'').replace(/\s+$/,'') + "')]";
				}
				else if (e.getAttribute('alt')) {
					return "//img[@id='"+id+"' and contains(@alt,'" + e.getAttribute('alt').replace(/^\s+/,'').replace(/\s+$/,'') + "')]";
				}
			}
		}
		return null;
});

/* We add a handler for images in lists. */
LocatorBuilders.add('imgTitleName', function(e) {
		if (e.nodeName == 'IMG') {
			if (e.getAttribute('name') && (e.getAttribute('title') || e.getAttribute('alt'))) {
				var name = e.getAttribute('name');
				if (e.getAttribute('title')) {
					return "//img[@name='"+name+"' and contains(@title,'" + e.getAttribute('title').replace(/^\s+/,'').replace(/\s+$/,'') + "')]";
				}
				else if (e.getAttribute('alt')) {
					return "//img[@name='"+name+"' and contains(@alt,'" + e.getAttribute('alt').replace(/^\s+/,'').replace(/\s+$/,'') + "')]";
				}
			}
		}
		return null;
});


/* We add a locator based on the name plus the id, which is better that the id alone, but more specific than id alone */
LocatorBuilders.add('nameAndId', function(e) {
		if (e.name && e.id) {
			return "//"+e.nodeName.toLowerCase()+"[@id='"+e.id+"' and @name='"+e.name+"']";
		}
		return null;
	});

/* We Override the default linkXPath to support nested text elements */
LocatorBuilders.add('linkXPath', function(e) {
		if (e.nodeName == 'A') {
			var text = e.textContent;
			if (!text.match(/^\s*$/)) {
				return "//a[contains(text(),'" + text.replace(/^\s+/,'').replace(/\s+$/,'') + "')]";
			}
		}
		else if (e.parentNode && e.parentNode.nodeName == 'A') {
			var elmt = e.nodeName.toLowerCase(); //This could be <span>, <p>, <div>, ...
			var text = e.textContent;
            		if (text && !text.match(/^\s*$/)) {
                		return "//a/"+elmt+"[contains(text(),'" + text.replace(/^\s+/,'').replace(/\s+$/,'') + "')]";
            		}
		}
		return null;
});

LocatorBuilders.order = ['name', 'linkXPath', 'imgTitleId', 'nameAndId', 'id', 'xpath:img', 'xpath:attributes', 
						'xpath:href',  /*'link', 'name', 'domFormElementName',*/ 
						/* Following locatorBuilders cannot return duplicate results and are the fallback methods: 'domFormElementIndex',*/  
						'xpath:position'];

var scenario = new Array();
var scenarioList = new Array();
var firstLoad = true;


function ScenarioEntry(sCommand,sTarget,sValue,sWindow) {
	this.command = sCommand;
	this.target = sTarget;
	this.value = sValue;
	this.window = sWindow;
}

ScenarioEntry.prototype.asCsv = function() {
	var text; 
	if(this.command=="comment")
		text = "|"+this.target;
	else 
		text = this.command+"|"+this.target+"|"+this.value+"|"+this.window;
	return text;
}

ScenarioEntry.prototype.asDisplayText = function()  {
	var text; 
	if(this.command=="click")
		text = this.command+" on element with id "+this.target+" in window "+this.window
	else if(this.command=="comment")
		text = "-comment- "+this.target;
	else
		text = this.command+" on element with id "+this.target+" with value "+this.value+" in window "+this.window
	return text
}

function startRecording() {
	editor.recordingEnabled = true;
	switchRecordButton();
	if(top.protoFrame.document.getElementById("historyDiv")==null) {
		createHistoryDiv();
		switchHistoryDiv();
	}
	firstLoad = false;
}

function stopRecording() {
	editor.recordingEnabled = false;
	switchRecordButton();
}

function switchHistoryDiv() {
	var div = top.protoFrame.document.getElementById("historyDiv");
	if(div.style.display=="none") {
		div.style.overflow = "auto";
		top.protoFrame.Effect.Appear('historyDiv', {duration: 0.5 });
	}
	else {
		div.style.overflow = "hidden";
		top.protoFrame.Effect.Fade('historyDiv', { duration: 0.5 });
	}
}

function updateList() {
	//var steps = parseStr(top.protoFrame.Sortable.serialize("scenarioList"));
	//scenarioList = steps.scenarioList;
	scenarioList = top.protoFrame.Sortable.sequence("scenarioList");
	
	return true;
}

function parseStr(s) {
  var rv = {}, decode = window.decodeURIComponent || window.unescape;
  (s == null ? location.search : s).replace(/^[?#]/, "").replace(
    /([^=&]*?)((?:\[\])?)(?:=([^&]*))?(?=&|$)/g,
    function ($, n, arr, v) {
      if (n == "")
        return;
      n = decode(n);
      v = decode(v);
      if (arr) {
        if (typeof rv[n] == "object")
          rv[n].push(v);
        else
          rv[n] = [v];
      } else {
        rv[n] = v;
      }
    });
  return rv;
}

function commentKeyUp(event) {
	if(event.keyCode ==13) {
		addComment(event)
	}
}

function addComment(event){
		editor.addCommand("comment",event.target.value,"",this.window);
		event.target.value = "Insert comment here";
}

function getCurrentStep() {
		var doc = top.protoFrame.document;
		var currentImg = doc.createElement("img");
		currentImg.src = window.currentImg;
		currentImg.style.margin = "0px 3px 0px 0px";
		var emptyInput = doc.createElement("input");
		emptyInput.setAttribute("type","text");
		emptyInput.size="37";
		emptyInput.defaultValue = "Insert comment here";
		emptyInput.style.border = "1px dashed #CCC";
		emptyInput.style.margin = "0px 0px 2px 0px";
		emptyInput.style.padding = "2px";
		emptyInput.style.color= "#1D4382"
		emptyInput.onkeyup = commentKeyUp;
		var handleImg = doc.createElement("img");
		handleImg.src = window.handleImg;
		handleImg.style.margin = "0px 0px 0px 2px";
		var firstChild = doc.createElement("li");
		firstChild.setAttribute("id","step_0");
		firstChild.style.border="1px solid #1D4382";
		firstChild.style.cursor="move";
		firstChild.style.padding="4px 2px 4px 2px";
		firstChild.appendChild(currentImg);
		firstChild.appendChild(emptyInput);
		firstChild.appendChild(handleImg);
		return firstChild;
}

function createHistoryDiv() {
		var doc = top.protoFrame.document;
		var newText = doc.createTextNode("TEST SCENARIO");		
		var newP = doc.createElement("h3");
		newP.style.textAlign = "center";
		newP.style.color = "#1D4382";
		newP.appendChild(newText);
		var firstChild = getCurrentStep();
		var newList = doc.createElement("ul");
		newList.setAttribute("id","scenarioList");
		newList.style.listStyleType="none";
		newList.style.width="275px";
		newList.style.marginLeft="10px"
		newList.style.paddingLeft="0px";
		newList.appendChild(firstChild);
		var newDiv = doc.createElement("div");
		newDiv.setAttribute('id', "historyDiv");
       	newDiv.style.width = "300px";
  	    newDiv.style.height = "300px";
   	    newDiv.style.position = "absolute";
       	newDiv.style.right = "5px";
       	newDiv.style.bottom = "30px";
		newDiv.style.border = "1px dashed #1D4382";
		newDiv.style.padding = "5px";
		newDiv.style.overflow = "scroll";
		newDiv.style.display = "none";
		newDiv.style.background = "#FFFFFF";
		newDiv.appendChild(newP);
		newDiv.appendChild(newList);
		doc.body.appendChild(newDiv);
		top.recorderFrame.document.getElementById("historySwitch").style.visibility="visible";
		top.recorderFrame.document.getElementById("downloadButton").style.visibility="visible";
		makeSortable(newList.id, updateList);
		Effect.Appear('hiddenButDiv', {duration:0.5 });
}


function makeSortable(id,func){
		top.protoFrame.Position.includeScrollOffsets = true;
		top.protoFrame.Sortable.create(id, {onUpdate:func, scroll: 'historyDiv'});
}

function reportReload() {
	if(!firstLoad) {
		createHistoryDiv();
		var index = 1;
		scenarioList.each(function(item) {
			if(item !=0) {
				var scenIndex = item-1;
				insertInList(scenario[scenIndex].asDisplayText(),item);
			}
		});
		top.protoFrame.Sortable.setSequence("scenarioList",scenarioList);
		editor.loadRecorder();
		top.protoFrame.document.getElementById('historyDiv').style.display="block";
		}
}

function switchRecordButton() {
	var doc = top.recorderFrame.document;
	var button =  doc.getElementById("recordButton");
	var img = button.firstChild;
	
	var inProgress =  doc.getElementById("inProgressDiv");
	
	if(img.alt=="Start recording") {
		img.src =	window.stopImg;
		img.alt="Stop recording"
		img.title="Stop recording"
		button.onclick = stopRecording;
		Effect.Appear('inProgressDiv', { duration: 0.5 });
	} else {
		img.src =	 window.recImg;
		img.alt="Start recording"
		img.title="Start recording"
		button.onclick = startRecording;
		Effect.Fade('inProgressDiv', { duration: 0.5 });
	}
}

function downloadScen() {
	if(scenarioList.length == 0)
		alert("Your scenario is empty");
	else {
		var doc = top.recorderFrame.document;
		var input = doc.getElementById( "scenario");
		var form = doc.getElementById( "scenarioHiddenForm");
		var text = "";
		var index = 1;
		scenarioList.each(function(item) {
			if(item!="0") {
				var scenIndex = item-1;
				var step = scenario[scenIndex].asCsv()+"\n";
				text = text.concat(step);
				index++;
			}
		});
		input.value = text;
		form.submit();
	}
}

function insertInList(text, index) {
	var doc = top.protoFrame.document
	var newLi = doc.createElement("li");
	var newText = doc.createTextNode(text);
	var stepId = "step_"+index;
	var deleteImg = doc.createElement("img");
	deleteImg.src = window.deleteImg;
	deleteImg.onclick = deleteInList;
	deleteImg.title = "Delete this step";
	deleteImg.id ="del_"+stepId;
	var editImg = doc.createElement("img");
	editImg.src = window.editImg;
	editImg.onclick = editInList;
	editImg.title = "Edit this step";
	editImg.id ="edit_"+stepId;
	var table = doc.createElement("table");
	var tBody = doc.createElement("tbody");
	table.appendChild(tBody);
	tBody.insertRow(0);
	tBody.rows[0].insertCell(0);
	tBody.rows[0].cells[0].appendChild(newText);
	tBody.rows[0].cells[0].style.width = "250px";
	tBody.rows[0].cells[0].style.color = "#1D4382";
	tBody.rows[0].insertCell(1);
	tBody.rows[0].cells[1].appendChild(editImg);
	tBody.rows[0].insertCell(2);
	tBody.rows[0].cells[2].appendChild(deleteImg);
	newLi.appendChild(table);
	newLi.setAttribute("id",stepId)
	var div = doc.getElementById( "historyDiv");
	div.scrollTop = div.scrollHeight;
	var list = doc.getElementById( "scenarioList");
	newLi.style.border="1px solid #1D4382";
	newLi.style.cursor="move";
	newLi.style.margin="2px 0px";
	newLi.style.padding="3px";
	list.insertBefore(newLi, doc.getElementById("step_0"));
	makeSortable(list.id, updateList);

}

function deleteInList(event) {
	var id = event.target.id.charAt(9);
	var pos = id-1;
	scenario[pos]="DELETED"
	var doc = top.protoFrame.document;
	var list = doc.getElementById( "scenarioList");
	var step = doc.getElementById("step_"+id);
	list.removeChild(step);
	updateList();
}

function editInList(event) {
 	var id = event.target.id.charAt(10);
 	var pos = id-1;
	var doc = top.protoFrame.document;
	var step = doc.getElementById("step_"+id);
	var tBody = step.firstChild.firstChild;
	var text = tBody.rows[0].cells[0].firstChild;
	var emptyInput = doc.createElement("input");
	emptyInput.setAttribute("type","text");
	emptyInput.size="35";
	emptyInput.id="step_"+id
	emptyInput.defaultValue = scenario[pos].asCsv();
	emptyInput.style.border = "1px dashed #CCC";
	emptyInput.style.margin = "0px 0px 0px 0px";
	emptyInput.style.padding = "2px";
	emptyInput.style.color= "#1D4382"
	emptyInput.onkeyup = editKeyUp;
	emptyInput.onblur = editCommand;
	tBody.rows[0].cells[0].replaceChild(emptyInput,text);
	event.target.onclick = submitEditButton;
}

function submitEditButton(event) {
	var id = event.target.id.charAt(10);
 	var pos = id-1;
	var doc = top.protoFrame.document;
	var input = doc.getElementById("step_"+id);
	var scen = input.value.split("|");
	if(scen[0] == "")
 		scen[0]="comment";
 	scenario[pos]= new ScenarioEntry(scen[0],scen[1],scen[2],scen[3]);
 	var newText = doc.createTextNode(scenario[pos].asDisplayText());
	input.parentNode.replaceChild(newText,input); 
	event.target.onclick = editInList;
}


function editKeyUp(event) {
	if(event.keyCode ==13) {
		editCommand(event)
	}
}

function editCommand(event){
	var doc = top.protoFrame.document;
	var id = event.target.id.charAt(5);
 	var pos = id-1;
 	var scen = event.target.value.split("|");
 	if(scen[0] == "")
 		scen[0]="comment";
 	scenario[pos]= new ScenarioEntry(scen[0],scen[1],scen[2],scen[3]);
 	var newText = doc.createTextNode(scenario[pos].asDisplayText());
	event.target.parentNode.replaceChild(newText,event.target); 
	var editButton = doc.getElementById("edit_step_"+id);
	editButton.onclick = editInList;	
}

function Editor() {
	this.window = top.protoFrame;
	this.log = new Log();
	this.recordingEnabled=false;
}

Editor.prototype.loadRecorder = function() {
	this.log.debug("Recorder loading on : " + this.window.name);
	recorder = Recorder.register(this, this.window);
	this.log.debug("Recorder loaded");
}

Editor.prototype.addCommand = function(command,target,value,window,insertBeforeLastCommand) {
	var text;
	var scenarioText = new ScenarioEntry(command,target,value,window.name);
	scenario.push(scenarioText);
	insertInList(scenarioText.asDisplayText(), scenario.length);
	updateList();
}

Editor.prototype.onUnloadDocument = function(doc) {
    var window = doc.defaultView;
    var self = this;
}

var editor = new Editor();
editor.loadRecorder();
