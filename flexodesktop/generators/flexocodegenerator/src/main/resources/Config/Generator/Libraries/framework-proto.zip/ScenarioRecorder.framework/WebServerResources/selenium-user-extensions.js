/*
 * Title: `Specific Selenium-IDE user-extensions
 * Description: This script contains various customizations for the default
 *              default selenium-ide.
 *
 * This component is part of a package allowing TestMaker 5.x
 * (http://www.pushtotest.com) to execute Selenium-IDE
 * (http://wiki.openqa.org/display/SIDE/Home) recorded test scenarios.
 * This extension package will remain accessible from the Open-Source section 
 * of the Denali web site: http://www.denali.be
 *
 */

/*
 * Main author(s): Olivier Dony, Denali
 * with contributions from other members of the Denali team  
 * $Id: selenium-user-extensions.js,v 1.1 2008/09/25 07:21:22 fdepasse Exp $
 */

/*
 * Copyright (c) 2007, Denali Consulting SA, Belgium
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Denali Consulting SA nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY Denali Consulting SA, Belgium, ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Denali Consulting SA, Belgium BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */


/* We redefine the recordTitle function here, to avoid hardcoding the application version
   when it is present in the title. */
Editor.prototype.recordTitleVersionRegexp = new RegExp(/\(([a-zA-Z0-9 ]+)?([0-9.]+)?\)$/);
Editor.prototype.recordTitle = function(window) {
	if (this.options.recordAssertTitle == 'true' && this.testCase.commands.length > 0) {
		var title = window.document.title;
		title = title.replace(Editor.prototype.recordTitleVersionRegexp,"*")
		this.addCommand("assertTitle", title, null, window);
	}
}

/*
 * We override the default click handler which works only in the
 * target & bubble phases, and we put it in the capturing phase.
 * The caveat is that some events which need to be recorded *before* the
 * click (such as chooseCancelOnNextConfirmation) might be recorded
 * *after*.
 * However this has the very nice property to enable recording clicks
 * with are connected to javascript event handlers that cancel the
 * bubbling phase (i.e, that use "return false"), but are still 
 * required for their other actions.
 *
 * See also: - recorder-handlers.js
 *           - http://www.w3.org/TR/DOM-Level-3-Events/events.html#Events-flow
 *           - http://developer.mozilla.org/en/docs/DOM:element.addEventListener
 */
Recorder.removeEventHandler('click');
Recorder.addEventHandler('click', 'click', function(event) {
        if (event.button == 0) {
            if (this.clickLocator) {
                this.record("click", this.clickLocator, '');
                delete this.clickLocator;
            }
        }
    }, { capture: true });





/* We override the findClickableElement to ignore certain elements that are not really relevant for clicks */
Recorder.prototype.findClickableElement = function(e) {
    if (!e.tagName) return null;
    var tagName = e.tagName.toLowerCase();
    var type = e.type;
        
    if (!(e.hasAttribute("ignoreClickable") || (e.hasAttribute("onclick") && e.getAttribute("onclick").toString().indexOf('event.cancelBubble') == 0 && e.getAttribute("onclick").toString().length == 24) ) &&
          (e.hasAttribute("onclick") || e.hasAttribute("href") || tagName == "button" ||
               (tagName == "input" && (type == "submit" || type == "button" || type == "image" || type == "radio" || type == "checkbox" || type == "reset"))
          )
       ) 
    {
        return e;
    } else {
        if (e.parentNode != null) {
            return this.findClickableElement(e.parentNode);
        } else {
            return null;
        }
    }
}

