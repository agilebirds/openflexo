/*
	Feel free to use your custom icons for the tree. Make sure they are all of the same size.
	User icons collections are welcome, we'll publish them giving all regards.
*/

var TREE_TPL = {
	'target'  : 'frameset',	// name of the frame links will be opened in
							// other possible values are: _blank, _parent, _search, _self and _top

	'icon_e'  : 'tigra_icons/tigra_empty.gif', // empty image
	'icon_l'  : 'tigra_icons/tigra_line.gif',  // vertical line

        'icon_32' : 'tigra_icons/tigra_folderopen.gif',   // root leaf icon normal
        'icon_36' : 'tigra_icons/tigra_folderopen.gif',   // root leaf icon selected
	
	'icon_48' : 'tigra_icons/tigra_folderopen.gif',   // root icon normal
	'icon_52' : 'tigra_icons/tigra_folderopen.gif',   // root icon selected
	'icon_56' : 'tigra_icons/tigra_folderopen.gif',   // root icon opened
	'icon_60' : 'tigra_icons/tigra_folderopen.gif',   // root icon selected
	
	'icon_16' : 'tigra_icons/tigra_folder.gif', // node icon normal
	'icon_20' : 'tigra_icons/tigra_folderopen.gif', // node icon selected
	'icon_24' : 'tigra_icons/tigra_folderopen.gif', // node icon opened
	'icon_28' : 'tigra_icons/tigra_folderopen.gif', // node icon selected opened

	'icon_0'  : 'tigra_icons/tigra_page.gif', // leaf icon normal
	'icon_4'  : 'tigra_icons/tigra_page.gif', // leaf icon selected
	
	'icon_2'  : 'tigra_icons/tigra_joinbottom.gif', // junction for leaf
	'icon_3'  : 'tigra_icons/tigra_join.gif',       // junction for last leaf
	'icon_18' : 'tigra_icons/tigra_plusbottom.gif', // junction for closed node
	'icon_19' : 'tigra_icons/tigra_plus.gif',       // junctioin for last closed node
	'icon_26' : 'tigra_icons/tigra_minusbottom.gif',// junction for opened node
	'icon_27' : 'tigra_icons/tigra_minus.gif',       // junctioin for last opended node
	
	'icon_65' : 'tigra_icons/tigra_BMP.gif',
	'icon_66' : 'tigra_icons/tigra_DOC.gif',
	'icon_67' : 'tigra_icons/tigra_EML.gif',
	'icon_68' : 'tigra_icons/tigra_GIF.gif',
	'icon_69' : 'tigra_icons/tigra_HTML.gif',
	'icon_70' : 'tigra_icons/tigra_JPG.gif',
	'icon_71' : 'tigra_icons/tigra_MP3.gif',
	'icon_72' : 'tigra_icons/tigra_MPG.gif',
	'icon_73' : 'tigra_icons/tigra_PDF.gif',
	'icon_74' : 'tigra_icons/tigra_PPT.gif',
	'icon_75' : 'tigra_icons/tigra_RA.gif',
	'icon_76' : 'tigra_icons/tigra_RTF.gif',
	'icon_77' : 'tigra_icons/tigra_SWF.gif',
	'icon_78' : 'tigra_icons/tigra_TIFF.gif',
	'icon_79' : 'tigra_icons/tigra_TXT.gif',
	'icon_80' : 'tigra_icons/tigra_WAV.gif',
	'icon_81' : 'tigra_icons/tigra_XLS.gif',
	'icon_82' : 'tigra_icons/tigra_ZIP.gif',
	
	'icon_93' : 'tigra_icons/tigra_fileUpload.gif',
	'icon_94' : 'tigra_icons/tigra_folder.gif',
	'icon_95' : 'tigra_icons/tigra_delete.gif',
	'icon_96' : 'Contento/Contento_Icon_AddFile.gif'
	
};

